// Additional translation unit for the header-only configuration test

#include "fmt/core.h"
