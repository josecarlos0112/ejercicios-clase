#include <iostream>
#define PI 3.14159
#define AREA_CIRCULO(r) (PI * (r) * (r))


int main() {
    std::cout << "Hello, World!" << std::endl;
    double radio = 10.0;
    double area = AREA_CIRCULO(radio);
    std::cout << "Area del Circulo: " << area << std::endl;
    return 0;
}
