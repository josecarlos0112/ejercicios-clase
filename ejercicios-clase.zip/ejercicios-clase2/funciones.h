//
// Created by usuario on 19/10/2023.
//

#ifndef EJERCICIOS_CLASE2_FUNCIONES_H
#define EJERCICIOS_CLASE2_FUNCIONES_H


class funciones {

};


#endif //EJERCICIOS_CLASE2_FUNCIONES_H
