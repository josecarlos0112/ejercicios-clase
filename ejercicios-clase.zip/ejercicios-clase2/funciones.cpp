#include "funciones.h"
#include <iostream>

int suma(int a, int b) {
    return a + b;
}

int resta(int a, int b) {
    return a - b;
}

double producto(double a, double b) {
    return a * b;
}

double division(double a, double b) {
    if (b != 0) {
        return a / b;
    } else {
        std::cerr << "Error: División por cero." << std::endl;
        return 0;
    }
}