# ejercicios-clase
Colección de Ejercicios para Nociones Clave
